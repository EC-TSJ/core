package core

/*******************************************************************************
 *  for Get/Set functions
 *******************************************************************************
 *! @Abstract
 *! @interface
 */
type IGetter[T Ordered] interface {
	Get() T
	Set(T)
}

const (
	_Class_  = 0
	_Method_ = 1
)

/*******************************************************************************
 * ATypes[T ordered]. @Abstract Class de la que dependen las demás.
 *******************************************************************************
 *! @Abstract
 *! @Class
 */
type ATypes[T Ordered] struct {
	/**
	 *! @implements
	 */IGetter IGetter[T]
	__assigned bool // solo para ReadOnly
	__key      T    // valor
}

/*******************************************************************************
 */
func __cce[T Ordered](g *ATypes[T], v int) {
	if g.IGetter == nil {
		var (
			s string = [...]string{"Class", "Method"}[v]
		)
		panic("ReferenceError: Abstract " + s + ": Don't Execute.")
	}
}

/*******************************************************************************
 *! @static
 *! @constructor
 */
func (*ATypes[T]) _new_(val T) *ATypes[T] {
	return &ATypes[T]{IGetter: nil, __key: val, __assigned: true}
}

/*******************************************************************************
 *! @static
 *! @constructor
 */
func (g *ATypes[T]) New() {
	__cce(g, _Class_)
}

/*******************************************************************************
 */
func (g *ATypes[T]) __panicking() {
	__cce(g, _Method_)
}

/*******************************************************************************
 *!@virtual
 */
func (g *ATypes[T]) Get() T {
	g.__panicking()
	return g.__key
}

/*******************************************************************************
 *!@virtual
 */
func (g *ATypes[T]) Set(value T) {
	g.__panicking()
}

/*******************************************************************************
 * Nos da un valor de tipo ReadOnly.
 * Se asigna un valor de inicio pero ya no se puede modificar
 *******************************************************************************
 *! @Class
 */
type ReadOnly[T Ordered] struct {
	/**
	 *! @extends
	 */ATypes[T]
}

// type ReadOnly[T Ordered] Property[T]

/*******************************************************************************
 *! @static
 *! @constructor
 */
func (ro *ReadOnly[T]) New(value T) *ReadOnly[T] {
	var (
		nil T
		rd  *ReadOnly[T] = ro
	)
	if !ro.__assigned {
		rd = &ReadOnly[T]{*(&ATypes[T]{})._new_(value)}
		rd.IGetter = rd
		if value == nil {
			rd.__assigned = false
		}
	}
	return rd
}

/*******************************************************************************
 *! @override
 */
func (ro *ReadOnly[T]) Set(value T) {
	if !ro.__assigned {
		ro.__key = value
		ro.__assigned = true
	}
}

/*******************************************************************************
 * Nos da un valor de tipo Const.
 *******************************************************************************
 *! @Class
 */
type Const[T Ordered] struct {
	/**
	 *! @extends
	 */ATypes[T]
}

/*******************************************************************************
 *! @static
 *! @constructor
 */
func (ct *Const[T]) New(val T) *Const[T] {
	var (
		_const *Const[T] = ct
	)
	if !ct.__assigned {
		_const = &Const[T]{*(&ATypes[T]{})._new_(val)}
		_const.IGetter = _const
	}
	return _const
}

/*******************************************************************************
 * Nos da un valor de tipo Static. Del tipo static de C, no de las clases de
 * instancia/valor.
 * Los límites en donde se mueve son Upper y Lower, de Java, p. ej.
 *******************************************************************************
 *! @Class
 */
type Static[T Number] struct {
	/**
	 *! @extends
	 */ATypes[T]
	Lower int // lower index for print
	Upper int // upeer index for print
}

/*******************************************************************************
 *! @static
 *! @constructor
 */
func (sta *Static[T]) New(val T) *Static[T] {
	st := &Static[T]{*(&ATypes[T]{})._new_(val), 0, 9223372036854775806}
	st.IGetter = st
	return st
}

/*******************************************************************************
 *!@override
 */
func (sta *Static[T]) Get() T {
	if sta.__key > T(sta.Upper) {
		sta.__key = T(sta.Lower)
	}
	pd := sta.__key
	sta.__key += T(1)
	return pd
}

//------------------------------------------------------------------------------
type Prop byte

const (
	// Lector de propiedades habilitado
	T_PROPGET Prop = 0b0001
	// Escritor de propiedades habilitado
	T_PROPSET Prop = 0b0010
	// valor cero
	zero Prop = 0
)

/*******************************************************************************
 * Nos da un dato. Del que sea s/ T.
 * Se puede usar como las propiedades Get/Set de C#, en
 * tal caso, se usan las constantes T_PROPGET y  T_PROPSET
 * para controlar cual son las funciones que se asignan: Get
 * ó Set.
 * Se usa como el segundo parámetro de New(Value, [Propertys]),
 * ó directamente a través de la propiedad Prop. Así:
 * InstanceVar(propertyInstance[type]).Prop = T_PROPGET | T_PROPSET.
 *******************************************************************************
 *! @Class
 */
type Property[T Ordered] struct {
	/**
	 *! @extends
	 */ATypes[T]
	Prop Prop
}

/*******************************************************************************
 *! @static
 * !@constructor
 */
func (prop *Property[T]) New(value T, t ...Prop) *Property[T] {
	var (
		_prop *Property[T] = prop
		z     Prop
	)
	if !prop.__assigned {
		z = optional[Prop](zero, t...)
		_prop = &Property[T]{ATypes: *(&ATypes[T]{})._new_(value), Prop: If[Prop](t == nil)(T_PROPGET|T_PROPSET, z)}
		_prop.IGetter = _prop
	}
	return _prop
}

/*******************************************************************************
 *! @override
 */
func (prop *Property[T]) Get() T {
	if prop.Prop&T_PROPGET == T_PROPGET {
		return prop.__key
	}
	return *new(T) //Default[T]()
}

/*******************************************************************************
 *! @override
 */
func (prop *Property[T]) Set(value T) {
	if prop.Prop&T_PROPSET == T_PROPSET {
		prop.__key = value
	}
}

func optional[T Ordered](_default T, _optional ...T) T {
	if len(_optional) > 0 {
		return _optional[0]
	}
	return _default
}
