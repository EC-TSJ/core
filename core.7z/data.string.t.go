/************************************/
/*  (%T% %S%), %J% <$B$> <$1.00$>   */
/*  (%W% 30-09-1991 )               */
/*  (%X%            )               */
/*  (%M%            )               */
/*  <$  $>                          */
/************************************/

package core

import (
	"strconv"
	"strings"
)

/**
 *! @Class
 */
//type dataS[T g.Ordered] string

type String = data[string]

/**
 * Convierte a minúsculas la cadena
 *! @return {string}
 */
func /* @public */ (str data[T]) ToLower() string {
	return strings.ToLower(interface{}(str).(string))
}

/**
 * Convierte a mayúsculas la cadena
 *! @return {string}
 */
func /* @public */ (str data[T]) ToUpper() string {
	return strings.ToUpper(interface{}(str).(string))
}

/**
 * Nos dice si la cadena contiene a 'search'
 *! @param {string}
 *! @return {bool}
 */
func /* @public */ (str data[T]) Contains(search string) bool {
	return strings.Contains(interface{}(str).(string), search)
}

/**
 * Nos dice el índice en donde se encuentra en la cadena
 *! @param {string}
 *! @return {int}
 */
func /* @public */ (str data[T]) Index(search string) int {
	return strings.Index(interface{}(str).(string), search)
}

/**
 * Divide la cadena en una lista de cadenas divididas por el separador sep
 *! @param {string}
 *! @return {bool}
 */
func /* @public */ (str data[T]) Split(sep string) []string {
	return strings.Split(interface{}(str).(string), sep)
}

/**
 * Elimina los 'set' caracteres de alrededor de la cadena
 *! @param {string}
 *! @return {string}
 */
func /* @public */ (str data[T]) Trim(set string) string {
	return strings.Trim(interface{}(str).(string), set)
}

func /* @public */ (d data[T]) AtoI() int {
	s, _ := strconv.Atoi(interface{}(d).(string))
	return s
}

// Parsea una cadena a entero
func /* @public */ (d data[T]) ParseInt() int {
	s, _ := strconv.ParseInt(interface{}(d).(string), 10, 64)
	return int(s)
}

// Parsea una cadena a unsigned entero
func /* @public */ (d data[T]) ParseUInt(data string) uint {
	s, _ := strconv.ParseUint(data, 10, 64)
	return uint(s)
}

//!-
