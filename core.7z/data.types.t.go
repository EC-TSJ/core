package core

import (
	"fmt"
	in "std/internal"
	cmp "std/mixin/comparable"
	eq "std/mixin/equatable"
	"std/refl"
)

/**
 *! @private @Class
 */
type /** @private */ data[T Ordered] struct {
	/**
	 *! @mixin
	 */
	*cmp.MCompareTo[T]
	/**
	 *! @mixin
	 */
	*eq.MEqualTo[T]
	val T
}

// Obtiene el tipo del dato
// ! @return {string}
func /** @public */ (d *data[T]) GetType() string {
	return refl.GetType(d)
}

// Retorna el TypeCode del dato
// ! @return {TypeCode}
func /** @public */ (d *data[T]) TypeCode() in.TypeCode {
	switch d.__what() {
	case "int":
		return in.INT64
	case "uint":
		return in.UINT64
	case "int8":
		return in.INT8
	case "uint8":
		return in.UINT8
	case "int16":
		return in.INT16
	case "uint16":
		return in.UINT16
	case "int32":
		return in.INT32
	case "uint32":
		return in.UINT32
	case "int64":
		return in.INT64
	case "uint64":
		return in.UINT64
	case "string":
		return in.STRING
	}
	return in.EMPTY
}

// helper function
func /** @private */ (d *data[T]) __what() string {
	var (
		x any = d.val
	)
	str := fmt.Sprintf("%T", x)
	return str
}

// Crea el tip de dato
// ! @type {T} Ordered
// ! @param {T}
// ! @retuns {*data[T]}
func /** @public */ (*data[T]) New(v T) *data[T] {
	return &data[T]{val: v,
		MEqualTo:   &eq.MEqualTo[T]{MEqual: &eq.MEqual[T]{Equal_fld: v}},
		MCompareTo: &cmp.MCompareTo[T]{MCompare: &cmp.MCompare[T]{Val_fld: v}}}
}
