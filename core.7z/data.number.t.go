/************************************/
/*  (%T% %S%), %J% <$B$> <$1.00$>   */
/*  (%W% 30-09-1991 )               */
/*  (%X%            )               */
/*  (%M%            )               */
/*  <$  $>                          */
/************************************/

package core

import (
	"fmt"
	"strconv"
)

const (
	_UNUSED_ int = -2
)

type Int = data[int]
type Int8 = data[int8]
type Int16 = data[int16]
type Int32 = data[int32]
type Int64 = data[int64]
type UInt = data[uint]
type UInt8 = data[uint8]
type UInt16 = data[uint16]
type UInt32 = data[uint32]
type UInt64 = data[uint64]
type Float32 = data[float32]
type Float64 = data[float64]

/**
 * Otorga un valor al dato
 *! @param {T}
 *! @return {*data[T]}
 *? @static
 */
func (d *data[T]) SetValue(v T) {
	d.val = v
}

func (d *data[T]) GetValue() T {
	return d.val
}

// Recibe un valor del dato
// ! @return {T}
// func (d *data[T]) ToIntXX() T {
// 	return any(d.val).(T)
// }

// Representa el más largo valor posible de un *data[T].
// ! @return {T}
func (d *data[T]) Max() T {
	str := d.__what()
	switch str {
	case "int":
		return any(9223372036854775807).(T) // (T)(void *)data
	case "uint":
		return any(uint(18446744073709551615)).(T) //1<<64 - 1
	case "int8":
		return any(127).(T)
	case "uint8":
		return any(255).(T)
	case "int16":
		return any(32767).(T)
	case "uint16":
		return any(65535).(T)
	case "int32":
		return any(2147483647).(T)
	case "uint32":
		return any(4294967295).(T)
	case "int64":
		return any(9223372036854775807).(T)
	case "uint64":
		return any(uint64(18446744073709551615)).(T)
	case "string":
		return any("[string]").(T)
	}

	return any(9223372036854775807).(T)
}

// Representa el más corto valor posible de un *data[T].
// ! @return {T}
func (d *data[T]) Min() T {
	str := d.__what()
	switch str {
	case "int":
		return any(-9223372036854775808).(T)
	case "uint", "uint8", "uint16", "uint32", "uint64":
		return any(0).(T)
	case "int8":
		return any(-128).(T)
	case "int16":
		return any(-32768).(T)
	case "int32":
		return any(-2147483648).(T)
	case "int64":
		return any(-9223372036854775808).(T)
	case "string":
		return any("[string]").(T)
	}

	return any(0).(T)
}

// IStringer
func (d *data[T]) String() string {
	return fmt.Sprint(d.val)
}

// Da el Hash de la cantidad.
// ! @return {int}
func (d *data[T]) GetHashCode() int {
	return any(d.val).(int)
}

// Parsea un entero a float
// ! @return {float64}
func (d *data[T]) ParseFloat() float64 {
	var (
		p float64
	)
	switch g := any(d).(type) {
	case float32, float64:
		p = g.(float64)
	}

	return float64(p)
}

// Parsea un entero a complex
// ! @return {complex128}
func (d *data[T]) ParseComplex() complex128 {
	s, _ := strconv.ParseComplex(d.ItoA(), 128)
	return s
}

// Parsea un entero a bool
// ! @return {bool}
/* @public */
func (d *data[T]) ParseBool() bool {
	s, _ := strconv.ParseBool(d.ItoA())
	return s
}

// Parsea un entero a string
// ! @return {string}
/* @public */
func (d *data[T]) ItoA() string {
	var (
		p int
	)
	switch g := any(d).(type) {
	case int, int8, int16, int32, int64, uint, uint8, uint16, uint32, uint64:
		p = g.(int)
	}
	return strconv.Itoa(p)
}

// !+
