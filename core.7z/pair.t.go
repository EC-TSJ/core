package core

import "reflect"

/*******************************************************************************
 * Tipo Pair
 *! @Class
 *! @type {T1 any}
 *! @type {T2 anyº}
 */
/** @Class */
type Pair[T1, T2 any] struct {
	T1 T1
	T2 T2
}

/*******************************************************************************
 * Crea un nuevo Pair[T,T]
 *! @param {T1}
 *! @param {T2}
 *! @returns {*Pair[T1, T2]}
 */
/** @static @constructor */
func (*Pair[T1, T2]) New(t1 T1, t2 T2) *Pair[T1, T2] {
	return &Pair[T1, T2]{T1: t1, T2: t2}
}

/*******************************************************************************
 * Obtiene el parámetro T1
 *! @returns {T1}
 */
/** @public */
func (pair *Pair[T1, T2]) GetT1() T1 {
	return pair.T1
}

/*******************************************************************************
 * Obtiene el parámetro T2
 *! @returns {T2}
 */
/** @public */
func (pair *Pair[T1, T2]) GetT2() T2 {
	return pair.T2
}

////////////////////////////////////////////////////////////////////////////////
//! @Stringer
func (pair *Pair[T1, T2]) String() string {
	t := reflect.TypeOf(pair)
	return If[string](t.Kind() == reflect.Ptr)("*"+t.Elem().Name(), t.Name())
}
